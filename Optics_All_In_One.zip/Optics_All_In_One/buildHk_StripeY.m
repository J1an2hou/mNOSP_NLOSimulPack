function [Hk,dHdk,d2Hdk2] ...
    = buildHk_StripeY(HR,wtR,R,wc,nw,kpt,alatt,blatt,nL)
% We build a slab model of nL unit cells, terminated along y
% Hence only the x (R1) is Fourier transformed
% This can be used to calculate surface state of a bullk system
% The orbital sequences are 1, ..., nw (in cell-1), 1, ..., nw (in cell-2)
% ..., until cell-nL
% Actually this is just half way of building Green function
% see RecursiveGreenStripY_FloquetA.m script for information
[HkPn,dHdkPn,d2Hdk2Pn]=buildHkAlongb1(R,HR,wtR,wc,nw,kpt,alatt,blatt);
Hk = zeros(nL*nw,nL*nw);
dHdk = zeros(nL*nw,nL*nw,3);
d2Hdk2 = zeros(nL*nw,nL*nw,6);
R2max = max(R(:,2));
R2min = min(R(:,2));
for iL = 1:nL
for jL = 1:nL
    iR2 = jL-iL+1-R2min; % this only works for nL big enough, good in most cases
    if iR2 < 1 || iR2 > R2max-R2min+1
        continue
    end
    Hk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw) = HkPn(:,:,iR2);
    dHdk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,1) = dHdkPn(:,:,iR2,1);
    dHdk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,2) = dHdkPn(:,:,iR2,2);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,1) = d2Hdk2Pn(:,:,iR2,1);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,2) = d2Hdk2Pn(:,:,iR2,2);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,6) = d2Hdk2Pn(:,:,iR2,6);
end
end

rdn = -6;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);

end