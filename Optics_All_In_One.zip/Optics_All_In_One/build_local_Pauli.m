function [spx, spy, spz] = build_local_Pauli(wl, nw)
nwl = max(wl);
wl_half = wl(1:nw/2); % this is the default basis set sequence
% wl_half = wl(1:2:nw); % use this line if spin_up, dn, up, dn, ... 
sigmax = [0, 1; 1, 0];
sigmay = [0, -1i; 1i, 0];
sigmaz = [1, 0; 0, -1];
spx = zeros(nw, nw, nwl);
spy = zeros(nw, nw, nwl);
spz = zeros(nw, nw, nwl);
for iwl = 1:nwl
    compared = kroneckerDelta(wl_half,sym(iwl));
    local = diag(compared);
    spx(:,:,iwl) = kron(sigmax, local);
    spy(:,:,iwl) = kron(sigmay, local);
    spz(:,:,iwl) = kron(sigmaz, local);
end

end