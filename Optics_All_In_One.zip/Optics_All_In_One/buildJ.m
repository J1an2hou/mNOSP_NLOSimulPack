function [Jx, Jy, Jz] = buildJ(orbital_seq)
norbitals = 0;
 
for iorbital = 1:length(orbital_seq)
  j = orbital_seq(iorbital);
  norbitals = norbitals + (2*j+1);
end
 
Jx = zeros(norbitals, norbitals);
Jy = zeros(norbitals, norbitals);
Jz = zeros(norbitals, norbitals);
 
count = 1;
for iorbital = 1:length(orbital_seq)
  j = orbital_seq(iorbital);
  [this_Jx, this_Jy, this_Jz] = J_angular(j);
  Jx(count:count+2*j, count:count+2*j) = this_Jx;
  Jy(count:count+2*j, count:count+2*j) = this_Jy;
  Jz(count:count+2*j, count:count+2*j) = this_Jz;
  count = count+2*j+1;
end
 
I2 = eye(2);  % spinor
Jx = kron(I2, Jx);
Jy = kron(I2, Jy);
Jz = kron(I2, Jz);

end