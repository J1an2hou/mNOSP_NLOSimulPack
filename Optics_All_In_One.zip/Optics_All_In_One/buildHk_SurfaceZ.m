function [Hk,dHdk,d2Hdk2] ...
    = buildHk_SurfaceZ(HR,wtR,R,wc,nw,kpt,alatt,blatt,nL)
% We build a supercell of nL unit cells, terminated along z
% This can be used to calculate surface state of a bullk system
% The orbital sequences are 1, ..., nw (in cell-1), 1, ..., nw (in cell-2)
% ..., until cell-nL
[HkPn,dHdkPn,d2Hdk2Pn]=buildHkAlongb1b2(R,HR,wtR,wc,nw,kpt,alatt,blatt);
Hk = zeros(nL*nw,nL*nw);
dHdk = zeros(nL*nw,nL*nw,3);
d2Hdk2 = zeros(nL*nw,nL*nw,6);
R3max = max(R(:,3));
R3min = min(R(:,3));
for iL = 1:nL
for jL = 1:nL
    iR3 = jL-iL+1-R3min; % this only works for nL big enough, good in most cases
    if iR3 < 1 || iR3 > R3max-R3min+1
        continue
    end
    Hk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw) = HkPn(:,:,iR3);
    dHdk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,1) = dHdkPn(:,:,iR3,1);
    dHdk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,2) = dHdkPn(:,:,iR3,2);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,1) = d2Hdk2Pn(:,:,iR3,1);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,2) = d2Hdk2Pn(:,:,iR3,2);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,6) = d2Hdk2Pn(:,:,iR3,6);
end
end

rdn = -6;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);

end