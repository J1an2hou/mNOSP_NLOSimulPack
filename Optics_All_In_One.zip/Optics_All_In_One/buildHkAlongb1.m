function [Hk, dHdk, d2Hdk2] = buildHkAlongb1(R,HR,wtR,wc,nw,kpt,alatt,blatt)
% Here only R1 is Fourier transformed, for edge along a2, so kx is
% well-defined only
nR = size(R,1);
R2max = max(R(:,2));
R2min = min(R(:,2));
nR2 = R2max-R2min+1;
Hk = zeros(nw,nw,nR2);
dHdk = zeros(nw,nw,nR2,3);
d2Hdk2 = zeros(nw,nw,nR2,6);
bk = kpt*blatt;
for iR = 1:nR
    wcdiff1 = wc(:,1)*ones(1,nw)-ones(nw,1)*wc(:,1)';
    aR = R(iR,:)*alatt;
    aR1 = aR(1) - wcdiff1;
    R2indx = R(iR,2)+1-R2min;
    kdotR = aR1 * bk(1);
    expkr = exp(1i*kdotR);
    hr = squeeze(HR(iR,:,:));
    Hk(:,:,R2indx) = Hk(:,:,R2indx) + wtR(iR) * hr .* expkr;
    dHdk(:,:,R2indx,1) = dHdk(:,:,R2indx,1)+1i*wtR(iR)*aR1.*hr.*expkr;
    d2Hdk2(:,:,R2indx,1) = d2Hdk2(:,:,R2indx,1)-wtR(iR)*aR1.*aR1.*hr.*expkr;
end

rdn = -6;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);

end