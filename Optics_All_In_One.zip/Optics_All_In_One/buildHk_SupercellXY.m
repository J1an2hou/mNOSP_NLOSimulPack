function [Hk,dHdk,d2Hdk2] ...
        = buildHk_SupercellXY(R,HR,wtR,wc,nw,nR,kpt,nL1,nL2,alatt,blatt)
% Note that here kpoint coordinate is in direct mode (in unit of reciprocal
% space
% Here the kpt is measured according to the supercell. Hence one needs to
% convert the coordinate
% This function build up a supercell that is extended from the unit cell,
% by (nL1 x nL2) in the a1 and a2 lattice.
% The orbital is chosen according to N = nw/2 (in spinor)
% unitcells \otimes [|1,up>,...|N,up>,|1,dn>,...|N,dn>]
% Hence, the spin should be calculated by kron(eye(nL1*nL2,nL1*nL2),kron(Pauli,eye(nw,nw))

% ala_sc = [nL1;nL2;1] .* alatt;
bla_sc = blatt ./[nL1;nL2;1];
Hk = zeros(nw*nL1*nL2,nw*nL1*nL2);
dHdk = zeros(nw*nL1*nL2,nw*nL1*nL2,3);
d2Hdk2 = zeros(nw*nL1*nL2,nw*nL1*nL2,6); % 1: xx; 2: yy; 3: zz; 4: yz; 5: zx; 6: xy
bk = kpt*bla_sc;
for iL1 = 1:nL1
for iL2 = 1:nL2
    iblk = (iL1-1)*nL2+iL2;
    i_start = (iblk-1)*nw+1;
    i_end = iblk*nw;
    for iR = 1:nR
    wcdiff1 = wc(:,1)*ones(1,nw)-ones(nw,1)*wc(:,1)';
    wcdiff2 = wc(:,2)*ones(1,nw)-ones(nw,1)*wc(:,2)';
    wcdiff3 = wc(:,3)*ones(1,nw)-ones(nw,1)*wc(:,3)';
    aR = R(iR,:)*alatt;
    aR1 = aR(1) - wcdiff1;
    aR2 = aR(2) - wcdiff2;
    aR3 = aR(3) - wcdiff3;
    kdotR = aR1 * bk(1) + aR2 * bk(2) + aR3 * bk(3);
    hr = reshape(HR(iR,:,:),nw,nw);

    jL1 = mod(iL1 + R(iR,1),nL1);
    jL2 = mod(iL2 + R(iR,2),nL2);
    if jL1 == 0
        jL1 = nL1;
    end
    if jL2 == 0
        jL2 = nL2;
    end
    jblk = (jL1-1)*nL2+jL2;
    j_start = (jblk-1)*nw+1;
    j_end = jblk*nw;
    Hk(i_start:i_end,j_start:j_end) ...
        = Hk(i_start:i_end,j_start:j_end)+wtR(iR)*hr.*exp(1i*kdotR);
    dHdk(i_start:i_end,j_start:j_end,1) ...
        = dHdk(i_start:i_end,j_start:j_end,1)+1i*wtR(iR)*aR1.*hr.*exp(1i*kdotR);
    dHdk(i_start:i_end,j_start:j_end,2) ...
        = dHdk(i_start:i_end,j_start:j_end,2)+1i*wtR(iR)*aR2.*hr.*exp(1i*kdotR);
    dHdk(i_start:i_end,j_start:j_end,3) ...
        = dHdk(i_start:i_end,j_start:j_end,3)+1i*wtR(iR)*aR3.*hr.*exp(1i*kdotR);
    d2Hdk2(i_start:i_end,j_start:j_end,1) ...
        = d2Hdk2(i_start:i_end,j_start:j_end,1)-wtR(iR)*aR1.*aR1.*hr.*exp(1i*kdotR);
    d2Hdk2(i_start:i_end,j_start:j_end,2) ...
        = d2Hdk2(i_start:i_end,j_start:j_end,2)-wtR(iR)*aR2.*aR2.*hr.*exp(1i*kdotR);
    d2Hdk2(i_start:i_end,j_start:j_end,3) ...
        = d2Hdk2(i_start:i_end,j_start:j_end,3)-wtR(iR)*aR3.*aR3.*hr.*exp(1i*kdotR);
    d2Hdk2(i_start:i_end,j_start:j_end,4) ...
        = d2Hdk2(i_start:i_end,j_start:j_end,4)-wtR(iR)*aR2.*aR3.*hr.*exp(1i*kdotR);
    d2Hdk2(i_start:i_end,j_start:j_end,5) ...
        = d2Hdk2(i_start:i_end,j_start:j_end,5)-wtR(iR)*aR3.*aR1.*hr.*exp(1i*kdotR);
    d2Hdk2(i_start:i_end,j_start:j_end,6) ...
        = d2Hdk2(i_start:i_end,j_start:j_end,6)-wtR(iR)*aR1.*aR2.*hr.*exp(1i*kdotR);
    end

end
end

rdn = -8;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);
end


