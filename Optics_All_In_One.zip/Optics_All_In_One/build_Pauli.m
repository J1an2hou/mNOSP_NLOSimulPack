function [sx,sy,sz] = build_Pauli(nw,dir)
A = eye(nw/2);
sigmax = [0 1; 1 0];
sigmay = [0 -1i; 1i 0];
sigmaz = [1 0; 0 -1];
sigma0 = [1 0; 0 1];
% The basis function is |1,up>, |2,up>, ..., |1,dn>, |2,dn>, ...
sx = kron(sigmax, A);
sy = kron(sigmay, A);
sz = kron(sigmaz, A);
% Until now the usual case is here
if nargin == 2
    if nargout > 1
        error('If you assign a direction, you must output only one component!')
    end
    if dir == 0
        sx = kron(sigma0, A);
    elseif dir == 1
        sx = kron(sigmax, A);
    elseif dir == 2
        sx = kron(sigmay, A);
    elseif dir == 3
        sx = kron(sigmaz, A);
    else
        error('Check your spin direction, which is not 0 - 3')
    end
end

end