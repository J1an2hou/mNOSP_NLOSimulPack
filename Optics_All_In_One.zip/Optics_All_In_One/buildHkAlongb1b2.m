function [Hk,dHdk,d2Hdk2] ...
        = buildHkAlongb1b2(R,HR,wtR,wc,nw,kpt,alatt,blatt)
% Here only R1 and R2 are Fourier transformed
% This is usually for surface spectral function calculation from 3D bulk
% Wannier functions
nR = size(R,1);
R3max = max(R(:,3));
R3min = min(R(:,3));
nR3 = R3max-R3min+1;
Hk = zeros(nw,nw,nR3);
dHdk = zeros(nw,nw,nR3,3);
d2Hdk2 = zeros(nw,nw,nR3,6);
bk = kpt*blatt;
for iR = 1:nR
    wcdiff1 = wc(:,1)*ones(1,nw)-ones(nw,1)*wc(:,1)';
    wcdiff2 = wc(:,2)*ones(1,nw)-ones(nw,1)*wc(:,2)';
    aR = R(iR,:)*alatt;
    aR1 = aR(1) - wcdiff1;
    aR2 = aR(2) - wcdiff2;
    R3indx = R(iR,3)+1-R3min;
    kdotR = aR1 * bk(1) + aR2 * bk(2);
    expkr = exp(1i*kdotR);
    hr = reshape(HR(iR,:,:),nw,nw);
    Hk(:,:,R3indx) = Hk(:,:,R3indx) + wtR(iR) * hr .* expkr;
    dHdk(:,:,R3indx,1) = dHdk(:,:,R3indx,1)+1i*wtR(iR)*aR1.*hr.*expkr;
    dHdk(:,:,R3indx,2) = dHdk(:,:,R3indx,2)+1i*wtR(iR)*aR2.*hr.*expkr;
    d2Hdk2(:,:,R3indx,1) = d2Hdk2(:,:,R3indx,1)-wtR(iR)*aR1.*aR1.*hr.*expkr;
    d2Hdk2(:,:,R3indx,2) = d2Hdk2(:,:,R3indx,2)-wtR(iR)*aR2.*aR2.*hr.*expkr;
    d2Hdk2(:,:,R3indx,3) = d2Hdk2(:,:,R3indx,6)-wtR(iR)*aR1.*aR2.*hr.*expkr;
end

rdn = -8;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);
end