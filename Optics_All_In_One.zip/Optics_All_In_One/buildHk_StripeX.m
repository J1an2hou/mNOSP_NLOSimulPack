function [Hk,dHdk,d2Hdk2] ...
    = buildHk_StripeX(HR,wtR,R,wc,nw,kpt,alatt,blatt,nL)
% We build a slab model of nL unit cells, terminated along x (a1)
% Hence only the y (R2) is Fourier transformed
% This can be used to calculate surface state of a bullk system
% The orbital sequences are 1, ..., nw (in cell-1), 1, ..., nw (in cell-2)
% ..., until cell-nL
% Actually this is just half way of building Green function
% see RecursiveGreenStripX_FloquetA.m script for information
[HkPn,dHdkPn,d2Hdk2Pn]=buildHkAlongb2(R,HR,wtR,wc,nw,kpt,alatt,blatt);
Hk = zeros(nL*nw,nL*nw);
dHdk = zeros(nL*nw,nL*nw,3);
d2Hdk2 = zeros(nL*nw,nL*nw,6);
R1max = max(R(:,1));
R1min = min(R(:,1));
for iL = 1:nL
for jL = 1:nL
    iR1 = jL-iL+1-R1min; % this only works for nL big enough, good in most cases
    if iR1 < 1 || iR1 > R1max-R1min+1
        continue
    end
    Hk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw) = HkPn(:,:,iR1);
    dHdk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,1) = dHdkPn(:,:,iR1,1);
    dHdk((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,2) = dHdkPn(:,:,iR1,2);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,1) = d2Hdk2Pn(:,:,iR1,1);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,2) = d2Hdk2Pn(:,:,iR1,2);
    d2Hdk2((iL-1)*nw+1:iL*nw,(jL-1)*nw+1:jL*nw,6) = d2Hdk2Pn(:,:,iR1,6);
end
end

rdn = -6;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);

end