function [Hk,dHdk,d2Hdk2] ...
        = buildHk(R,HR,wtR,wc,nw,nR,kpt,alatt,blatt)
% Note that here kpoint coordinate is in direct mode (in unit of reciprocal
% space
Hk = zeros(nw,nw);
dHdk = zeros(nw,nw,3);
d2Hdk2 = zeros(nw,nw,6); % 1: xx; 2: yy; 3: zz; 4: yz; 5: zx; 6: xy
bk = kpt*blatt;
for iR = 1:nR
    wcdiff1 = wc(:,1)*ones(1,nw)-ones(nw,1)*wc(:,1)';
    wcdiff2 = wc(:,2)*ones(1,nw)-ones(nw,1)*wc(:,2)';
    wcdiff3 = wc(:,3)*ones(1,nw)-ones(nw,1)*wc(:,3)';
    aR = R(iR,:)*alatt;
    aR1 = aR(1) - wcdiff1;
    aR2 = aR(2) - wcdiff2;
    aR3 = aR(3) - wcdiff3;
    kdotR = aR1 * bk(1) + aR2 * bk(2) + aR3 * bk(3);
    hr = reshape(HR(iR,:,:),nw,nw);
    Hk = Hk + wtR(iR) * hr .* exp(1i*kdotR);
    if nargout > 1
    dHdk(:,:,1) = dHdk(:,:,1) + 1i*wtR(iR)*aR1 .* hr .* exp(1i*kdotR);
    dHdk(:,:,2) = dHdk(:,:,2) + 1i*wtR(iR)*aR2 .* hr .* exp(1i*kdotR);
    dHdk(:,:,3) = dHdk(:,:,3) + 1i*wtR(iR)*aR3 .* hr .* exp(1i*kdotR);
    end
    if nargout > 2
    d2Hdk2(:,:,1) = d2Hdk2(:,:,1)-wtR(iR)*aR1.^2.*hr.*exp(1i*kdotR);
    d2Hdk2(:,:,2) = d2Hdk2(:,:,2)-wtR(iR)*aR2.^2.*hr.*exp(1i*kdotR);
    d2Hdk2(:,:,3) = d2Hdk2(:,:,3)-wtR(iR)*aR3.^2.*hr.*exp(1i*kdotR);
    d2Hdk2(:,:,4) = d2Hdk2(:,:,4)-wtR(iR)*aR2.*aR3.*hr.*exp(1i*kdotR);
    d2Hdk2(:,:,5) = d2Hdk2(:,:,5)-wtR(iR)*aR3.*aR1.*hr.*exp(1i*kdotR);
    d2Hdk2(:,:,6) = d2Hdk2(:,:,6)-wtR(iR)*aR1.*aR2.*hr.*exp(1i*kdotR);
    end
end

rdn = -8;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);
end


