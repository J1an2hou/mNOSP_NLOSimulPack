function wrk = buildwrk(R,wr,wtR,nw,nR,kpt,alatt,blatt)
% We apply Fourier transformation to convert the Wannier90_r.dat results
% into k space. Here kpt is in direct mode (in unit of reciprocal lattice)
wrk = zeros(nw,nw,3);
bk = kpt*blatt;
for iR = 1:nR
    %wcdiff1 = wc(:,1)*ones(1,nw)-ones(nw,1)*wc(:,1)';
    %wcdiff2 = wc(:,2)*ones(1,nw)-ones(nw,1)*wc(:,2)';
    %wcdiff3 = wc(:,3)*ones(1,nw)-ones(nw,1)*wc(:,3)';
    aR = R(iR,:)*alatt;
    aR1 = aR(1); % - wcdiff1;
    aR2 = aR(2); % - wcdiff2;
    aR3 = aR(3); % - wcdiff3;
    kdotR = aR1 * bk(1) + aR2 * bk(2) + aR3 * bk(3);
    wx = reshape(wr(iR,:,:,1),nw,nw);
    wy = reshape(wr(iR,:,:,2),nw,nw);
    wz = reshape(wr(iR,:,:,3),nw,nw);
    wrk(:,:,1) = wrk(:,:,1) + wtR(iR) * wx .* exp(1i*kdotR);
    wrk(:,:,2) = wrk(:,:,2) + wtR(iR) * wy .* exp(1i*kdotR);
    wrk(:,:,3) = wrk(:,:,3) + wtR(iR) * wz .* exp(1i*kdotR);
end

rdn = -8;
wrk = roundn(wrk,rdn);
% wxk = diag(wrk(:,:,1));
% wyk = diag(wrk(:,:,2));
% wzk = diag(wrk(:,:,3));

end

