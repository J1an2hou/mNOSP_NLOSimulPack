function [Hk, dHdk, d2Hdk2] = buildHkAlongb2(R,HR,wtR,wc,nw,kpt,alatt,blatt)
% Here only R2 is Fourier transformed (periodic boundary), for edge vertical to a1
nR = size(R,1);
R1max = max(R(:,1));
R1min = min(R(:,1));
nR1 = R1max-R1min+1;
Hk = zeros(nw,nw,nR1);
dHdk = zeros(nw,nw,nR1,3);
d2Hdk2 = zeros(nw,nw,nR1,6);
bk = kpt*blatt;
for iR = 1:nR
    wcdiff2 = wc(:,2)*ones(1,nw)-ones(nw,1)*wc(:,2)';
    aR = R(iR,:)*alatt;
    aR2 = aR(2) - wcdiff2;
    R1indx = R(iR,1)+1-R1min;
    kdotR = aR2 * bk(2);
    expkr = exp(1i*kdotR);
    hr = squeeze(HR(iR,:,:));
    Hk(:,:,R1indx) = Hk(:,:,R1indx) + wtR(iR) * hr .* expkr;
    dHdk(:,:,R1indx,2) = dHdk(:,:,R1indx,2)+1i*wtR(iR)*aR2.*hr.*expkr;
    d2Hdk2(:,:,R1indx,2) = d2Hdk2(:,:,R1indx,2)-wtR(iR)*aR2.*aR2.*hr.*expkr;
end

rdn = -8;
Hk = roundn(Hk,rdn);
dHdk = roundn(dHdk,rdn);
d2Hdk2 = roundn(d2Hdk2,rdn);

end